package company;

import company.WestminsterSkinConsultationManager;

public class MainGUI extends WestminsterSkinConsultationManager {
    public static void main(String[] args){

        new TestGUI();
    }


}