package company;

import java.io.FileNotFoundException;

public class Main {
    public static void main(String[] args) {

        WestminsterSkinConsultationManager var2 = new WestminsterSkinConsultationManager();
        var2.recoverStats();
        var2.menuList();

    }
}
